// Graph buffer + drawing
