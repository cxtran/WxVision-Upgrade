#include <Arduino.h>
#include "buzzer.h"
#include "menu.h"
#include "display.h"  // your display driver with dma_display->print()
#include "buzzer.h"
#include <Preferences.h>  
#include "settings.h"

void handleIR(uint32_t code)
{
    switch (code)
    {
    case 0xFF02FD: // CH+ UP
        handleUp();
        playBuzzerTone(1500, 100);
        break;
    case 0xFF9867: // CH- DOWN
        handleDown();
        playBuzzerTone(1200, 100);
        break;
    case 0xFF906F: // >> RIGHT
        handleRight();
        playBuzzerTone(1800, 100);
        break;
    case 0xFFE01F: // << LEFT
        handleLeft();
        playBuzzerTone(900, 100);
        break;
    case 0xFFA857: // OK
        handleSelect();
        playBuzzerTone(2200, 100);
        break;
    default:
        Serial.printf("Unknown code: 0x%X\n", code);
        playBuzzerTone(500, 100);
        delay(100);
        playBuzzerTone(500, 100);
        break;
    }
}


MenuLevel currentMenuLevel = MENU_MAIN;
int currentMenuIndex = 0;

// Example: items for main menu
const char* mainMenuItems[] = {
  "Device Settings",
  "Display Settings",
  "Weather Settings",
  "Calibration",
  "System Actions",
  "Save & Exit"
};

const int mainMenuCount = sizeof(mainMenuItems) / sizeof(mainMenuItems[0]);
/*
// Placeholder function to show menu on screen
void drawMenu() {
  dma_display->clearScreen();
  dma_display->setCursor(0,0);
  dma_display->setTextColor(dma_display->color565(255,255,255));

  if (currentMenuLevel == MENU_MAIN) {
    for (int i=0; i < mainMenuCount; i++) {
      if (i == currentMenuIndex) dma_display->setTextColor(dma_display->color565(255,0,0));
      else dma_display->setTextColor(dma_display->color565(255,255,255));

      dma_display->setCursor(0, i*8);
      dma_display->print(mainMenuItems[i]);
    }
  }

  // Repeat for other menu levels...
}
*/

#include "menu.h"
#include "display.h"

MenuLevel currentMenuLevel = MENU_MAIN;
int currentMenuIndex = 0;

// Menu item arrays for each level
const char* mainMenu[] = {"Device Settings", "Display Settings", "Weather Settings", "Calibration", "System Actions", "Save & Exit"};
const int mainCount = sizeof(mainMenu)/sizeof(mainMenu[0]);

const char* deviceMenu[] = {"Units", "Day Format", "Forecast Source", "Auto Rotate", "Manual Screen", "Exit & Save"};
const int deviceCount = sizeof(deviceMenu)/sizeof(deviceMenu[0]);

const char* displayMenu[] = {"Theme", "Brightness", "Scroll Speed", "Custom Msg", "Exit & Save"};
const int displayCount = sizeof(displayMenu)/sizeof(displayMenu[0]);

const char* weatherMenu[] = {"OWM City", "OWM API Key", "WF Token", "WF Station ID", "Exit & Save"};
const int weatherCount = sizeof(weatherMenu)/sizeof(weatherMenu[0]);

const char* calibMenu[] = {"Temp Offset", "Hum Offset", "Light Gain", "Exit & Save"};
const int calibCount = sizeof(calibMenu)/sizeof(calibMenu[0]);

const char* systemMenu[] = {"OTA Update", "Reset Power", "Quick Restore", "Factory Reset", "Exit & Save"};
const int systemCount = sizeof(systemMenu)/sizeof(systemMenu[0]);

void drawMenu() {
    dma_display->clearScreen();
    dma_display->setCursor(0,0);
    dma_display->setTextColor(dma_display->color565(255,255,255));
    dma_display->setFont(&Font5x7Uts);

    if (currentMenuLevel == MENU_MAIN) {
        for (int i=0; i<mainCount; i++) {
            dma_display->setCursor(0, i*8);
            if (i == currentMenuIndex)
                dma_display->setTextColor(dma_display->color565(255,0,0));
            else
                dma_display->setTextColor(dma_display->color565(255,255,255));
            dma_display->print(mainMenu[i]);
        }
    }
    else if (currentMenuLevel == MENU_DEVICE) {
        for (int i=0; i<deviceCount; i++) {
            dma_display->setCursor(0, i*8);
            if (i == currentMenuIndex)
                dma_display->setTextColor(dma_display->color565(255,0,0));
            else
                dma_display->setTextColor(dma_display->color565(255,255,255));
            dma_display->print(deviceMenu[i]);
        }
    }
    else if (currentMenuLevel == MENU_DISPLAY) {
        for (int i=0; i<displayCount; i++) {
            dma_display->setCursor(0, i*8);
            if (i == currentMenuIndex)
                dma_display->setTextColor(dma_display->color565(255,0,0));
            else
                dma_display->setTextColor(dma_display->color565(255,255,255));
            dma_display->print(displayMenu[i]);
        }
    }
    else if (currentMenuLevel == MENU_WEATHER) {
        for (int i=0; i<weatherCount; i++) {
            dma_display->setCursor(0, i*8);
            if (i == currentMenuIndex)
                dma_display->setTextColor(dma_display->color565(255,0,0));
            else
                dma_display->setTextColor(dma_display->color565(255,255,255));
            dma_display->print(weatherMenu[i]);
        }
    }
    else if (currentMenuLevel == MENU_CALIBRATION) {
        for (int i=0; i<calibCount; i++) {
            dma_display->setCursor(0, i*8);
            if (i == currentMenuIndex)
                dma_display->setTextColor(dma_display->color565(255,0,0));
            else
                dma_display->setTextColor(dma_display->color565(255,255,255));
            dma_display->print(calibMenu[i]);
        }
    }
    else if (currentMenuLevel == MENU_SYSTEM) {
        for (int i=0; i<systemCount; i++) {
            dma_display->setCursor(0, i*8);
            if (i == currentMenuIndex)
                dma_display->setTextColor(dma_display->color565(255,0,0));
            else
                dma_display->setTextColor(dma_display->color565(255,255,255));
            dma_display->print(systemMenu[i]);
        }
    }
}

// Core menu update loop
void updateMenu() {
  // This function will be called in your main loop
  // Here, you check buttons & IR, and call handleUp/Down/Select
  drawMenu();
}

// Navigation functions
void handleUp() {
  currentMenuIndex--;
  if (currentMenuIndex < 0) currentMenuIndex = mainMenuCount-1;
  drawMenu();
}

void handleDown() {
  currentMenuIndex++;
  if (currentMenuIndex >= mainMenuCount) currentMenuIndex = 0;
  drawMenu();
}
 
void handleLeft() {
    if (currentMenuLevel == MENU_DEVICE) {
        if (currentMenuIndex == 0) toggleUnits(-1);       // Units
        if (currentMenuIndex == 1) toggleDayFormat(-1);   // Day Format
        if (currentMenuIndex == 2) toggleForecastSrc(-1); // Forecast Source
        if (currentMenuIndex == 3) toggleAutoRotate(-1);  // Auto rotate
    }
    else if (currentMenuLevel == MENU_DISPLAY) {
        if (currentMenuIndex == 0) toggleTheme(-1);
        if (currentMenuIndex == 1) adjustBrightness(-1);
        if (currentMenuIndex == 2) adjustScrollSpeed(-1);
    }
    else if (currentMenuLevel == MENU_CALIBRATION) {
        if (currentMenuIndex == 0) adjustTempOffset(-1);
        if (currentMenuIndex == 1) adjustHumOffset(-1);
        if (currentMenuIndex == 2) adjustLightGain(-1);
    }
    drawMenu();
}

void handleRight() {
    if (currentMenuLevel == MENU_DEVICE) {
        if (currentMenuIndex == 0) toggleUnits(1);
        if (currentMenuIndex == 1) toggleDayFormat(1);
        if (currentMenuIndex == 2) toggleForecastSrc(1);
        if (currentMenuIndex == 3) toggleAutoRotate(1);
    }
    else if (currentMenuLevel == MENU_DISPLAY) {
        if (currentMenuIndex == 0) toggleTheme(1);
        if (currentMenuIndex == 1) adjustBrightness(1);
        if (currentMenuIndex == 2) adjustScrollSpeed(1);
    }
    else if (currentMenuLevel == MENU_CALIBRATION) {
        if (currentMenuIndex == 0) adjustTempOffset(1);
        if (currentMenuIndex == 1) adjustHumOffset(1);
        if (currentMenuIndex == 2) adjustLightGain(1);
    }
    drawMenu();
}

void handleSelect() {
    if (currentMenuLevel == MENU_MAIN) {
        switch(currentMenuIndex) {
            case 0: currentMenuLevel = MENU_DEVICE; currentMenuIndex = 0; break;
            case 1: currentMenuLevel = MENU_DISPLAY; currentMenuIndex = 0; break;
            case 2: currentMenuLevel = MENU_WEATHER; currentMenuIndex = 0; break;
            case 3: currentMenuLevel = MENU_CALIBRATION; currentMenuIndex = 0; break;
            case 4: currentMenuLevel = MENU_SYSTEM; currentMenuIndex = 0; break;
            case 5: saveAllSettings(); currentMenuLevel = MENU_MAIN; currentMenuIndex = 0; break;
        }
    }
    else if (currentMenuLevel == MENU_DEVICE) {
        if (currentMenuIndex == deviceCount-1) { // Exit & Save
            saveDeviceSettings();
            currentMenuLevel = MENU_MAIN; currentMenuIndex = 0;
        }
    }
    else if (currentMenuLevel == MENU_DISPLAY) {
        if (currentMenuIndex == displayCount-1) {
            saveDisplaySettings();
            currentMenuLevel = MENU_MAIN; currentMenuIndex = 0;
        }
    }
    else if (currentMenuLevel == MENU_WEATHER) {
        if (currentMenuIndex == weatherCount-1) {
            saveWeatherSettings();
            currentMenuLevel = MENU_MAIN; currentMenuIndex = 0;
        }
    }
    else if (currentMenuLevel == MENU_CALIBRATION) {
        if (currentMenuIndex == calibCount-1) {
            saveCalibrationSettings();
            currentMenuLevel = MENU_MAIN; currentMenuIndex = 0;
        }
    }
    else if (currentMenuLevel == MENU_SYSTEM) {
        if (currentMenuIndex == systemCount-1) {
            saveSystemSettings();
            currentMenuLevel = MENU_MAIN; currentMenuIndex = 0;
        }
        else if (currentMenuIndex == 0) startOTA();
        else if (currentMenuIndex == 1) resetPowerUsage();
        else if (currentMenuIndex == 2) quickRestore();
        else if (currentMenuIndex == 3) factoryReset();
    }
    drawMenu();
}

