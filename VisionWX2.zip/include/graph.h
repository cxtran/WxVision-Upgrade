#pragma once
void updateGraphData();
